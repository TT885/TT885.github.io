#include <ctime>
#include <cstdio>
#include <iostream>
#include <cstdlib>
template <class T>
void randarray(T *a,T* b)
{
	srand(time(NULL));
	int len= (b-a)/sizeof(T);
	for(T*i=a;i!=b;++i)
	{
		int index=rand()%len;
		T x=a[index];
		a[index]=*i;
		*i=x;
	}
}
template<class T>
void qsort(T *a,T* b)
{
	if(!(a+1<b))
		return;
	T *i1=a,*i2=b-1,pivot=*a,*hole=a;
	while(i1<i2)
	{
		while(i1<i2&&!(*i2<pivot))	--i2;
		*hole=*i2,hole=i2;
		while(i1<i2&&*i1<pivot)		++i1;
		*hole=*i1,hole=i1;
	}
	*hole=pivot;
	qsort(a,i1);
	qsort(i1+1,b);
}

template<class T>
void merge(T*a,int high,int mid,int low)
{
    T temp[2][50005];
    int i,j=0,k=0;
    for(i=0;i<=mid-low;++i)
        temp[0][i]=a[low+i];
    for(i=0;i<high-mid;++i)
        temp[1][i]=a[mid+1+i];

    for(i=low;i<=high;++i)
    {
        if(j>mid-low || k<high-mid && temp[1][k]<temp[0][j])
            a[i]=temp[1][k++];
        else
            a[i]=temp[0][j++];
    }
}
template <class T>
void mergesort(T*a,int high,int low=0)
{
    if(high==low)
        return;
    int mid=(high+low)/2;
    mergesort(a,mid,low);
    mergesort(a,high,mid+1);
    merge(a,high,mid,low);
}
