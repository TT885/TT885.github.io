#include <iostream>
#include <cstdio>
#include <queue>
#include <cstring>
#include <vector>
using namespace std;
//Debug1:�����ں�������������������������WA�ˣ�����


struct po
{
    int dest,len;
    po(int dd=0,int ll=0):dest(dd),len(ll){}
    bool operator<(const po &p2) const
    {
        return len>p2.len;
    }
};
const int maxn=100005;
vector<po> wmap[maxn];
bool passed[maxn]={};
int BFS(int m,int n)
{
    priority_queue<po> q;
    q.push(po(m));
    while(!q.empty())
    {
        po p=q.top();q.pop();
        while(passed[p.dest])
            p=q.top(),q.pop();
        passed[p.dest]=1;

        if(p.dest==n)
        {
            cout<<p.len<<"\n";
            return p.len;
        }
        for(vector<po>::iterator iter=wmap[p.dest].begin();iter!=wmap[p.dest].end();++iter)
            if(!passed[iter->dest])
                q.push(po(iter->dest,iter->len+p.len));
    }
}


int main()
{
    int T,N,i,x,y,l;
    while(cin>>T>>N)
    {
        memset(passed,0,sizeof(passed));
        for(i=0;i<T;++i)
        {
            cin>>x>>y>>l;
            wmap[x].push_back(po(y,l));
            wmap[y].push_back(po(x,l));
        }
        BFS(1,N);
        //cout<<BFS(1,N)<<"\n";
    }
    return 0;
}
