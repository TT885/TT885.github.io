#include <iostream>
#include <cstdio>
using namespace std;
int a[300005];  //Debug1:�������(n-1)n/2,300000�ᵼ��int �����num���뿪long long,a[300005]������int

long long mergesort(int a[],int high,int low=0) //����ҿ�
{
    if (high==low+1)
        return 0;
    int mid= (high+low)>>1;
    long long cnt1=mergesort(a,mid,low),cnt2=mergesort(a,high,mid),cnt=0;
    int j=low,k=mid;
    int * aa=new int [300005];
    for (int i=low;i<high;++i)
    {
        if (j<mid && k<high)
        {
            if(a[j]<=a[k])
            {
                aa[i]=a[j];
                ++j;
            }
            else

            {
                aa[i]=a[k];
                ++k;++cnt;
            }
        }
        else if (k<high)
        {
            aa[i]=a[k];
            ++k;
        }
        else
        {
            aa[i]=a[j];
            ++j;++cnt;
        }
    }
    for (int i=low;i<high;++i)
        a[i]=aa[i];
    return cnt1+cnt2+cnt;
}


int main()
{
    freopen("data.txt","r",stdin);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int n;
    cin>>n;
    for(int i=0;i<n;++i)
        cin>>a[i];
    cout<<mergesort(a,n);
    return 0;
}
