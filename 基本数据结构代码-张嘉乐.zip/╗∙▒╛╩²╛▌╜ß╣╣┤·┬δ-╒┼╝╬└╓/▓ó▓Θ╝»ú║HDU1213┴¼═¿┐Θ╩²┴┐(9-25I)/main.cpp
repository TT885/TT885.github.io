#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
/*�����ܽ᣺
1.��ͨ����������׼�Ĳ��鼯��ע��findr()��unite()�ı�׼д��������par[x]==xΪ�оݣ�par[x]==0����������
*/

const int maxn=1005;
int T,n,m,par[maxn];
bool appeared[maxn];

inline int findr(int x)
{
    return par[x]==x?x:par[x]=findr(par[x]);
}
inline void unite(int x,int y)
{
    x=findr(x);y=findr(y);
    if(x!=y)
        par[x]=y;
}

int main()
{
    //freopen("data.txt","r",stdin);
    cin>>T;
    while(T--)
    {
        int i,x,y,res=0;
        cin>>n>>m;
        memset(appeared,0,sizeof(appeared));
        for(i=1;i<=n;++i)
            par[i]=i;
        for(i=0;i<m;++i)
        {
            cin>>x>>y;
            unite(x,y);
        }
        for(i=1;i<=n;++i)
        {
            x=findr(i);
            //cout<<"x="<<x<<"\n";
            if(!appeared[x])
                appeared[x]=1,++res;
        }
        cout<<res<<"\n";
    }
    return 0;
}
