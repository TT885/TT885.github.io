
template <class T> //ָ����״ʵ�֣�merge()������BUG
class pri_queue
{
    struct treenode
    {
        T data;
        treenode *lf,*rt,*pa;
        treenode(T d,treenode *pp=NULL,treenode*ll=NULL,treenode *rr=NULL):data(d),pa(pp),lf(ll),rt(rr){}
        treenode():pa(NULL),lf(NULL),rt(NULL){}
    }*root,*leaf;
    void swapp( T &a,T &b)
    {
        T tmp2=a;
        a=b;
        b=tmp2;
    }
    void shiftdown()
    {
        treenode *p=root,*q=root;
        while(p->lf || p->rt)
        {
            if(p->lf && p->rt)
            {
                q=p->data<p->rt->data?p->rt:p;
                q=q->data<p->lf->data?p->lf:q;
                if(q!=p)
                {
                    swapp(p->data,q->data);
                    p=q;
                }
                else
                    break;
            }
            else if(p->lf)
            {
                if(p->data<p->lf->data)
                {
                    swapp(p->data,p->lf->data);
                    p=p->lf;
                }
                else
                    break;
            }
            else
            {
                if(p->data<p->rt->data)
                {
                    swapp(p->data,p->rt->data);
                    p=p->rt;
                }
                else
                    break;
            }
        }
    }
    void shiftup(treenode * p)
    {
        while(p->pa && p->pa->data<p->data)
            swapp(p->pa->data,p->data),p=p->pa;
    }
public:
    pri_queue():root(NULL){}
    void push(T x)
    {
        treenode * p=root;
        while(p)
        {
            if(!p->lf)
            {
                p=p->lf=new treenode(x,p);
                break;
            }
            else if(!p->rt)
            {
                p=p->rt=new treenode(x,p);
                break;
            }
            p=p->lf;
        }
        if(!root)
            root=new treenode(x);
        else
            shiftup(p);
    }
    bool empty()
    {
        return root==NULL;
    }
    T top()
    {
        if(root)
            return root->data;
    }
    void pop()  //��֤û�п������ҵĽڵ�
    {
        treenode *p=root;
        while(p->rt||p->lf)
        {
            if(p->rt)
                p=p->rt;
            else
                p=p->lf;
        }
        if(p==root)
            root=NULL;
        else
        {
            p=p->pa;
            if(p->rt)
                root->data=p->rt->data,p->rt=NULL;
            else
                root->data=p->lf->data,p->lf=NULL;
            shiftdown();
        }
    }
    void merge(pri_queue& que2)
    {
        if(!que2.root)
        {
            return;
        }
        if(!root)
        {
            root=que2.root;
            return;
        }
        treenode *p=root;
        while(p->rt)
            p=p->rt;
        if(p==root)
        {
            p->lf=que2.root;
            que2.root->pa=p;
            shiftdown();
        }
        else
        {
            p=p->pa;
            if(p->rt)
            {
                p->rt->lf=root,root->pa=p->rt;
                p->rt->rt=que2.root;que2.root->pa=p->rt;
                root=p->rt,root->pa=NULL;
                p->rt=NULL;
            }
            else
            {
                p->lf->lf=root,root->pa=p->lf;
                p->lf->rt=que2.root;que2.root->pa=p->lf;
                root=p->lf,root->pa=NULL;
                p->rt=NULL;
            }
            shiftdown();
        }
    }
    void clear()
    {
        root=NULL;
    }
};

template <class T> /*�����ʵ�֣��ɺϲ�,doublespace()������*/
class pri_queue
{
    T* heap;
    int len,si;
    void doublesize()
    {
        T * h=new T [si];
        for(int i=0;i<si;++i)
            h[i]=heap[i];
        delete []heap;
        heap=new T[si<<=1];
        for(int i=0;i<si;++i)
            heap[i]=h[i];
    }
    void shiftup()
    {
        int p=len;
        while(p>1 && heap[p]>heap[p>>1]) //ά���󶥶�,���������й�3��>���ɱ�ΪС����
        {
            T t=heap[p];
            heap[p]=heap[p>>1];
            heap[p>>1]=t;
            p=p>>1; //���ƽڵ�
        }
    }
    void shiftdown(int p=1)
    {
        while((p<<1)<=len)
        {
            int q=heap[p<<1]>heap[p]?p<<1:p;  //�����
            if((p<<1)<len) //�Ҷ��Ӵ��ڣ��Ƚϣ�����д�����⣺q=((p<<1)<l&&heap[q]<heap[(p<<1)+1])?q:(p<<1)+1;
            q=heap[q]>heap[(p<<1)+1]?q:(p<<1)+1;
            if(q!=p)
            {
                T t=heap[p];
                heap[p]=heap[q];
                heap[q]=t;
                p=q;  //���ƽڵ�
            }
            else
                break;
        }
    }
public:
    pri_queue(int ss=1000000):si(ss),len(0){heap=new T[si];}
    void push(T x)
    {
        if(len==si-1)
        {
            doublesize();
        }
        heap[++len]=x;
        shiftup();
    }
    T top()
    {
        return heap[1];
    }
    void pop()
    {
        heap[1]=heap[len--];
        shiftdown();
    }
    bool empty()
    {
        return len==0;
    }
    void merge(pri_queue<T> &que2)
    {
        while(len+que2.len>=si)
            doublesize();
        int i;
        for(i=1;i<=que2.len;++i)
            heap[len+i]=que2.heap[i];
        len+=que2.len;
        for(i=len>>1;i>0;--i)
            shiftdown(i);
    }
};
template <class T>  /*����ʵ�֣��ɺϲ�*/
class pri_queue
{
    struct node
    {
        T data;
        node* next;
        node(T x,node* nn=NULL):data(x),next(nn){}
        node():next(NULL){}
    }*head;
public:
    pri_queue(){head=new node();}
    void push(T x)
    {
        node *p=head;
        while(p->next && x<p->next->data)
            p=p->next;
        p->next=new node(x,p->next);
    }
    T top()
    {
        return head->next->data;
    }
    void pop()
    {
        if(head->next)
            head->next=head->next->next;
    }
    bool empty()
    {
        return head->next==NULL;
    }
    void merge(pri_queue &que2)
    {
        node* p=head,*q=que2.head;
        while(p->next&&q->next)
        {
            if(p->next->data<q->next->data)
                p=p->next=new node(q->next->data,p->next),q=q->next;
            else
                p=p->next;
        }
        while(q->next)
            p=p->next=new node(q->next->data,p->next),q=q->next;
    }
};
