#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;

int n,m,par[55];
struct road
{
    int start,dest,distan;
    road(int st=0,int de=0,int di=0):start(st),dest(de),distan(di){}
    bool operator<(const road &r2)const
    {
        return distan>r2.distan;
    }
};
inline int findr(int x)
{
    return x==par[x]?x:par[x]=findr(par[x]);
}
inline void unite(int x,int y)
{
    x=findr(x);y=findr(y);
    if(x!=y)
        par[x]=y;
}

int main()
{
    //freopen("data.txt","r",stdin);
    int i,s,d,dis;
    while(cin>>n&&n)
    {
        cin>>m;
        priority_queue<road> pq;
        for(i=0;i<=n;++i)
            par[i]=i;
        while(m--)
        {
            cin>>s>>d>>dis;
            pq.push(road(s,d,dis));
        }
        int res=0;
        while(--n)
        {
            road r1=pq.top();
            pq.pop();
            while(findr(r1.start)==findr(r1.dest))
                r1=pq.top(),pq.pop();
            res+=r1.distan;
            unite(r1.start,r1.dest);
        }
        cout<<res<<"\n";
    }
    return 0;
}
