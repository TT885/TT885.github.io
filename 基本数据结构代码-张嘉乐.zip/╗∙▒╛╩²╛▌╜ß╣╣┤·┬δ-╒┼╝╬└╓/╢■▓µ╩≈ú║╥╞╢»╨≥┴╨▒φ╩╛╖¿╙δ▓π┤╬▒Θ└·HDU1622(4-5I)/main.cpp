#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>
#include <vector>
using namespace std;

bool repeat;
class Binarytree
{
    struct node
    {
        int value;
        node *leftc,*rightc;
        bool have_value;
        node(int vv=0,node* ll=NULL,node* rr=NULL,bool hh=0):value(vv),leftc(ll),rightc(rr),have_value(hh){}
    }*root,*p;
    char s[500];
    void remove(node*p)
    {
        if(!p) return;
        remove(p->leftc);
        remove(p->rightc);
        delete p;
    }
public:
    Binarytree(){root=new node;}
    ~Binarytree()
    {
        remove(root);
    }
    bool addnode(int v,char *s)
    {
        int n=strlen(s),i;
        p=root;
        for(i=0;i<n;++i)
        {
            if(s[i]=='L')
            {
               if(p->leftc)
                    p=p->leftc;
               else
                    p=p->leftc=new node;
            }
            else if(s[i]=='R')
            {
               if(p->rightc)
                    p=p->rightc;
               else
                    p=p->rightc=new node;
            }
        }
        if(p->have_value)  //�Ѿ���ֵ�����ٸ�ֵ
        {
            repeat=1;
            return 0;
        }
        p->value=v;
        p->have_value=1;
        return 1;
    }
    bool read_input()
    {
        while(1)
        {
            if(scanf("%s",s)!=1)
                return 0;
            if(strcmp(s,"()")==0)
                break;
            int v;
            sscanf(s+1,"%d",&v);//�ַ�����ɨ������
            addnode(v,strchr(s,',')+1);//�ַ�������ȡ�ִ�
        }
        return 1;
    }
    bool bfs(vector<int> &ans)
    {
        queue<node*> q;
        ans.clear();
        q.push(root);
        while(!q.empty())
        {
            p=q.front();
            q.pop();
            if(!p->have_value)
                return 0;
            if(p->leftc)
                q.push(p->leftc);
            if(p->rightc)
                q.push(p->rightc);
            ans.push_back(p->value);
        }
        return 1;
    }

};


int main()
{
    //freopen("data.txt","r",stdin);
    vector<int> ans;
    bool first=1;
    while(1)
    {
        Binarytree tree;
        repeat=0;
        if(!tree.read_input())
            return 0;

        if(first)
            first=0;
        else
            cout<<'\n';   //�����ĩβ�಻���ʽ����ǰ���Ҫ��
        if(!repeat  &&tree.bfs(ans))
            for(vector<int>::iterator iter=ans.begin();iter!=ans.end();++iter)
            {
                cout<<*iter;
                if(iter+1!=ans.end())
                    cout<<" ";  //���Ҫ���ʽ��
            }
        else
            cout<<"not complete";

    }
    return 0;
}
