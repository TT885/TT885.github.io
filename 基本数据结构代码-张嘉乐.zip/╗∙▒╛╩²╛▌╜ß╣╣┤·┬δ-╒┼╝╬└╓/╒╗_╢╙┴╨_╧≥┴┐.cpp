template <class T>
    class stack
    {
        struct node
        {
            T data;
            node *next;
            node(T x,node * nn=NULL):data(x),next(nn){}
        }*head;
    public:
        stack():head(NULL){}
        ~stack()
        {
            if(head)
            {
                node* p=head->next;
                while(p)
                {
                    head->next=p->next;
                    delete p;
                    p=head->next;
                }
                delete head;
            }
        }
        void push(T x)
        {
            head=new node(x,head);
        }
        T top()
        {
            return head->data;
        }
        void pop()
        {
            if(head)
                head=head->next;
        }
        bool empty()
        {
            return !head;
        }
    };

template <class T>
class queue
{
    T* q;
    int head,rear,si;
    void doublesize()
    {
        T *h=new T[si];
        for(int i=0;i<si;++i)
            h[i]=q[(head+i)%si];
        delete []q;
        head=0;rear=si;
        q=new T[si<<=1];
        for(int i=head;i<rear;++i)
            q[i]=h[i];
        delete []h;
    }
public:
    queue(int ss=300000):head(0),rear(0),si(ss){q=new T[si];}//�����ԣ�����������������
    ~queue(){delete []q;}
    void push(T x)
    {
        q[rear++]=x;
        rear%=si;
        if(rear==head)
            doublesize();
    }
    T front()
    {
        return q[head];
    }
    T back()
    {
        if(rear)
            return q[rear-1];
        return q[si-1];
    }
    void pop_front()
    {
        if(head!=rear)
            head=(head+1)%si;
    }
    void pop()
    {
        if(head!=rear)
            head=(head+1)%si;
    }
    void pop_back()
    {
        if(head!=rear)
        {
            rear-=1;
            if(rear<0)
                rear+=si;
        }
    }
    void clear()
    {
        head=rear=0;
    }
    bool empty()
    {
        return head==rear;
    }
};

template <class T>  //��̬��������,���������⣬�����ӣ����ݴ��SJOJ4271RE��
    class vector
    {
        T * a;
        int len,si;
        void doublesize()  
        {
            T * h=new T [si];
            for(int i=0;i<si;++i)
                h[i]=a[i];
            delete []a;
            a=new T[si<<=1];
            for(int i=0;i<si;++i)
                a[i]=h[i];
            delete []h;
        }
    public:
        vector(int ss=100000):si(ss),len(0){a=new T[si];}
        int size()
        {
            return len;
        }
        void push_back(T x)
        {
            if(len==si)
                doublesize();
            a[len++]=x;
        }
        void del(T x)
        {
            for(int i=0;i<len;++i)
                if(a[i]==x)
                {
                    --len;
                    for(int j=i;j<len;++j)
                        a[j]=a[j+1];
                }
        }
        T &operator[](int k)
        {
            return a[k];
        }
    };//*/

template <class T>  //��������
class vector
{
    struct node
    {
        T data;
        node *next;
        node():next(NULL){}
        node(T x,node *nn=NULL):data(x),next(nn){}
    }*head,*p,*rear;
    int len;
public:
    vector():len(0){rear=head=new node();}
    int length()
    {
        return len;
    }
    void push_back(T x)
    {
        rear=rear->next=new node(x);
        ++len;
    }
    void del(T x)
    {
        p=head;
        while(p->next->data!=x)
            p=p->next;
        p->next=p->next->next; //�ڴ�й©��
        --len;
    }
    T &operator[](int k)
    {
        p=head->next;
        for(int i=0;i<k;++i)
            p=p->next;
        return p->data;
    }
    bool operator==(const vector<T> &v2)
    {
        if(len!=v2.len)
            return 0;
        node *p1=head->next,*p2=v2.head->next;
        while(p1)
        {
            if(p1->data!=p2->data)
                return 0;
            p1=p1->next;p2=p2->next;
        }
        return 1;
    }

    void clear()
    {
        rear=head=new node;len=0; //�����ڴ�й©��Ҫ��������Ҫ��ɾ���ȥ������
    }
    vector<T> &operator+=(const vector<T> &v2)
    {
        node* p2=v2.head->next;
        while(p2)
        {
            rear=rear->next=new node(p2->data);
            ++len;p2=p2->next;
        }
        return *this;
    }
    void display()
    {
        p=head->next;
        while(p)
            cout<<p->data<<" ",p=p->next;
    }
};
